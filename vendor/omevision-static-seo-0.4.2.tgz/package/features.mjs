import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {join,dirname} from 'node:path';
import {createHash} from 'node:crypto';
import {rewriteHead} from './head.mjs';
import {escapeHtml as e} from './edge.mjs';
import {renderVideo,validateVideo,mediaCss,mediaRuntime} from './media.mjs';

export const featurePath = (feature) => feature.existing_path || feature.path || `/features/${feature.slug}`;
const playerFile='guide-player-'+createHash('sha256').update(mediaRuntime).digest('hex').slice(0,12)+'.js';
const hubPath=(p)=>p.feature_base||'/features';
const homePath=(p)=>p.home_path||'/';
const paragraphs = (text) => String(text).split(/\n\n+/).filter(Boolean).map(p=>`<p>${e(p)}</p>`).join('');
const heading = (title,body) => `<section><h2>${e(title)}</h2>${body}</section>`;
const link = (url,label,cls='') => `<a${cls?` class="${cls}"`:''} href="${e(url)}">${e(label)}</a>`;
function validLink(value) {
 if(typeof value!=='string'||/[\x00-\x20<>]/.test(value))throw new Error('Invalid feature link');
 const url=new URL(value,'https://example.invalid');
 if(!['https:','http:'].includes(url.protocol)||url.username||url.password)throw new Error('Unsafe feature link');
}
export function validateProduct(product) {
 validateVideo(product.video);
 if(!product.id||!product.name||!Array.isArray(product.features)||!product.features.length)throw new Error('Missing feature product data');
 if(new URL(`https://${product.canonical_host}`).hostname!==product.canonical_host)throw new Error('Invalid canonical host');
 const paths=new Set();
 for(const f of product.features){
  const path=featurePath(f);if(!/^\/(?:[a-z0-9-]+\/?)+$/.test(path)||paths.has(path))throw new Error(`Invalid/duplicate feature path: ${path}`);paths.add(path);
  for(const key of ['title','description','headline','intro','audience'])if(typeof f[key]!=='string'||!f[key].trim())throw new Error(`Incomplete feature ${path}: ${key}`);
  if(!f.sources?.length||!f.steps?.length||!f.benefits?.length)throw new Error(`Missing evidence or workflow: ${path}`);
  const cta=f.cta||product.cta;validLink(cta.url);if(!cta.label)throw new Error(`Missing feature CTA: ${path}`);
 }
}
const css=`:root{color-scheme:light;--ink:#17211e;--muted:#52625c;--paper:#fafbf8;--accent:#17654a;--line:#dce3dd}*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:var(--paper);color:var(--ink);font:17px/1.7 var(--font,system-ui,sans-serif)}a{color:var(--accent);text-underline-offset:.22em}a:focus-visible,summary:focus-visible{outline:3px solid var(--accent);outline-offset:5px}a:hover{text-decoration-thickness:2px}.skip{position:absolute;left:1rem;top:-5rem;background:white;padding:.5rem}.skip:focus{top:1rem}.shell{width:min(1120px,calc(100% - 40px));margin:auto}.brand{font-size:1.25rem;font-weight:750;text-decoration:none;color:var(--ink)}header{border-bottom:1px solid var(--line)}header .shell,footer .shell{display:flex;gap:24px;justify-content:space-between;align-items:center;padding-block:24px;flex-wrap:wrap}nav{display:flex;gap:24px;flex-wrap:wrap}nav a{font-size:.9rem}main{padding-block:64px}.eyebrow{font-size:.75rem;font-weight:700;letter-spacing:.13em;text-transform:uppercase;color:var(--accent)}h1{max-width:21ch;font-size:clamp(2.2rem,5vw,4.3rem);line-height:1.1;letter-spacing:-.04em;margin:20px 0 28px}h2{font-size:clamp(1.5rem,3vw,2rem);line-height:1.25;letter-spacing:-.025em}h3{font-size:1.15rem;line-height:1.4}p{max-width:73ch}.intro{font-size:1.2rem;max-width:70ch}.button{display:inline-block;background:var(--accent);color:white;border-radius:8px;padding:13px 22px;font-weight:650;text-decoration:none}.hero-actions{display:flex;gap:24px;align-items:center;flex-wrap:wrap;margin-top:28px}.rule{height:1px;background:var(--line);margin:54px 0}section{padding-block:20px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,260px),1fr));gap:20px}.card{padding:26px;border:1px solid var(--line);border-radius:12px;background:white}.card h2,.card h3{margin-top:0}.card p{font-size:.95rem;color:var(--muted)}ol{max-width:75ch;padding-left:1.5rem}li{padding-left:.4rem;margin-bottom:18px}.note{background:white;border-left:3px solid var(--accent);padding:20px 26px;border-radius:0 8px 8px 0}.note p:last-child{margin-bottom:0}.crumbs{font-size:.85rem;margin-bottom:34px;display:flex;gap:12px;flex-wrap:wrap}.section-label{color:var(--muted);font-size:.9rem}footer{border-top:1px solid var(--line);font-size:.9rem;color:var(--muted)}@media(max-width:600px){main{padding-block:36px}header .shell{gap:12px}nav{gap:16px}.hero-actions{align-items:flex-start;flex-direction:column}.rule{margin:32px 0}.card{padding:22px}}`;
const guideCss=`.guide-hero{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.1fr);gap:44px;align-items:center;margin:12px 0 48px}.guide-hero h1{font-size:clamp(2.2rem,4.3vw,3.7rem);max-width:20ch}.guide-hero .intro{font-size:1.1rem}.guide-hero section{padding:0}.guide-steps{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,210px),1fr));gap:18px;list-style:none;max-width:none;padding:0}.guide-steps li{padding:22px;border:1px solid var(--line);border-radius:12px;background:white}.guide-steps span{font-size:.8rem;color:var(--accent);font-weight:750}.guide-steps p{margin:14px 0 0}.guide-details{margin:24px 0;padding:20px 0;border-block:1px solid var(--line)}.guide-details summary{cursor:pointer;font-weight:650}.guide-close{margin:32px 0;display:flex;justify-content:space-between;align-items:center;gap:24px;flex-wrap:wrap;border-bottom:1px solid var(--line);padding-bottom:42px}.guide-close h2{margin:0}@media(max-width:800px){.guide-hero{grid-template-columns:1fr;gap:32px}.guide-hero h1{max-width:24ch}.guide-steps{grid-template-columns:1fr 1fr}}@media(max-width:600px){header .shell{padding-block:16px}main{padding-block:24px}.crumbs{margin-bottom:20px}.guide-hero .eyebrow{margin:8px 0}.guide-hero h1{margin:12px 0 16px}.guide-hero .intro{font-size:1rem;line-height:1.6}.guide-hero .hero-actions{margin-top:20px;gap:14px}.guide-hero{gap:24px}}@media(max-width:480px){.guide-steps{grid-template-columns:1fr}.guide-hero{margin-bottom:28px}}`;
function documentFor(template,product,meta,body){
 const origin=`https://${product.canonical_host}`;
 const assets=[...template.matchAll(/<(?:link|meta)\b[^>]*(?:rel=["'](?:icon|apple-touch-icon|preconnect)["']|name=["']theme-color["'])[^>]*>/gi)].map(x=>x[0]).join('\n');
 const style=`:root{--accent:${product.theme?.accent||'#17654a'};--ink:${product.theme?.ink||'#17211e'};--paper:${product.theme?.paper||'#fafbf8'}}`;
 const html=`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">${assets}<style>${css}${mediaCss}${guideCss}${style}</style><script src="/_marketing/${playerFile}" defer></script></head><body><a class="skip" href="#content">Skip to content</a><header><div class="shell">${link(homePath(product),product.name,'brand')}<nav aria-label="Main navigation">${link(hubPath(product),'Features')}</nav></div></header><main id="content" class="shell">${body}</main><footer><div class="shell"><span>${e(product.name)} · Part of ${link('https://omevision.com/','Omevision')}</span><nav aria-label="Footer">${link(homePath(product),'Overview')}${link(hubPath(product),'All features')}</nav></div></footer></body></html>`;
 return rewriteHead(html,{...meta,canonical:origin+meta.path});
}
function featureBody(product,f){
 const cta=f.cta||product.cta,video=f.video||product.video;
 const watchLabel=f.video?'Watch how it works':'Watch the '+product.name+' overview';
 const introParts=String(f.intro).split(/\n\n+/).map(x=>x.trim()).filter(Boolean);
 const detail=[...new Set([...(f.paragraphs||[]),...introParts.slice(1)])].filter(p=>p.trim()!==introParts[0]);
 const steps=f.steps.map((step,index)=>`<li><span aria-hidden="true">${String(index+1).padStart(2,'0')}</span><p>${typeof step==='string'?e(step):`<strong>${e(step.title)}</strong> ${e(step.body)}`}</p></li>`).join('');
 const notes=[...detail,...(f.example?[typeof f.example==='string'?f.example:f.example.body||f.example.description]:[]),...(f.limitations?[Array.isArray(f.limitations)?f.limitations.join('\n\n'):f.limitations]:[])].filter(Boolean);
 return `<nav class="crumbs" aria-label="Breadcrumb">${link(homePath(product),product.name)}<span aria-hidden="true">/</span>${link(hubPath(product),'Features')}</nav><div class="guide-hero"><div><p class="eyebrow">${e(f.label||f.slug.replaceAll('-',' '))}</p><h1>${e(f.headline)}</h1><p class="intro">${e(introParts[0])}</p><div class="hero-actions">${link(cta.url,cta.label,'button')}<a href="#watch" data-watch-video>${e(watchLabel)}</a></div></div>${renderVideo(video,{heading:f.video?'See how it works':product.name+' overview'})}</div>${heading('How to get started',`<ol class="guide-steps">${steps}</ol>`)}<section aria-label="What you can do"><div class="grid">${f.benefits.slice(0,3).map(b=>`<article class="card"><h2>${e(b.title)}</h2>${paragraphs(b.body)}</article>`).join('')}</div></section>${notes.length?`<details class="guide-details"><summary>A few useful details</summary>${notes.map(paragraphs).join('')}</details>`:''}<section class="guide-close"><h2>Ready to try it?</h2>${link(cta.url,cta.label,'button')}</section>${heading('More from '+product.name,`<div class="grid">${product.features.filter(x=>x.slug!==f.slug).map(x=>`<article class="card"><h3>${link(featurePath(x),x.label||x.title.replace(/\s*\|.*$/,''))}</h3>${paragraphs(x.description)}</article>`).join('')}</div>`)}`;
}
export function featureMetadata(product,f){
 const origin=`https://${product.canonical_host}`,path=featurePath(f);
 return {path,title:f.title,description:f.description,noindex:Boolean(product.noindex||f.noindex),canonical:origin+path,structuredData:{'@context':'https://schema.org','@graph':[{'@type':'WebPage','@id':origin+path+'#page',url:origin+path,name:f.title,description:f.description,isPartOf:{'@type':'WebSite',name:product.name,url:origin+'/'}},{'@type':'BreadcrumbList',itemListElement:[{'@type':'ListItem',position:1,name:product.name,item:origin+'/'},{'@type':'ListItem',position:2,name:'Features',item:origin+hubPath(product)},{'@type':'ListItem',position:3,name:f.label||f.title,item:origin+path}]}]}};
}
export async function buildFeatures({dist,product,preserveExisting=[],homeFile='index.html',preserveHub=false}){
 validateProduct(product);
 await mkdir(join(dist,'_marketing'),{recursive:true});
 await writeFile(join(dist,'_marketing',playerFile),mediaRuntime);
 const template=await readFile(join(dist,homeFile),'utf8');
 const entries=[];
 for(const f of product.features){
  const path=featurePath(f);entries.push({path,title:f.title,description:f.description,noindex:Boolean(product.noindex||f.noindex)});
  // Existing authored pages remain authoritative; their prerender is handled by the product's renderer.
  if(preserveExisting.includes(path))continue;
  const html=documentFor(template,product,featureMetadata(product,f),featureBody(product,f));
  const file=join(dist,path.slice(1).replace(/\/$/,'')+'.html');await mkdir(dirname(file),{recursive:true});await writeFile(file,html);
 }
 const hub={path:hubPath(product),noindex:Boolean(product.noindex),title:`${product.name} features`,description:`See what ${product.name} can do and how to get started.`};
 const cards=product.features.map(f=>`<article class="card"><h2>${link(featurePath(f),f.label||f.title.replace(/\s*\|.*$/,''))}</h2>${paragraphs(f.description)}</article>`).join('');
 if(!preserveHub)await writeFile(join(dist,hubPath(product).slice(1)+'.html'),documentFor(template,product,hub,`<div class="guide-hero"><div><p class="eyebrow">${e(product.name)}</p><h1>${e(product.guide?.headline||product.name+' features')}</h1><p class="intro">${e(product.guide?.summary||product.audience)}</p><div class="hero-actions">${link(product.cta.url,product.cta.label,'button')}<a href="#watch" data-watch-video>Watch how it works</a></div></div>${renderVideo(product.video)}</div>${product.guide?.steps?.length?heading('How to get started',`<ol class="guide-steps">${product.guide.steps.map((step,index)=>`<li><span aria-hidden="true">${String(index+1).padStart(2,'0')}</span><p>${e(step)}</p></li>`).join('')}</ol>`):''}<section><h2>Choose what you want to do</h2><div class="grid" aria-label="Product features">${cards}</div></section><section class="guide-close"><h2>Ready to try it?</h2>${link(product.cta.url,product.cta.label,'button')}</section>`));
 entries.unshift(hub);
 const nav=`<section id="omevision-feature-directory-${product.id}" aria-label="${e(product.name)} features" style="padding:32px max(20px,calc((100% - 1120px)/2));font:16px/1.7 system-ui;background:${product.theme?.paper||'#fafbf8'};color:${product.theme?.ink||'#17211e'};border-top:1px solid #dce3dd"><h2 style="font-size:24px">Explore ${e(product.name)} features</h2><ul style="display:flex;flex-wrap:wrap;gap:12px 28px;padding-left:20px">${product.features.map(f=>`<li>${link(featurePath(f),f.label||f.title.replace(/\s*\|.*$/,''))}</li>`).join('')}</ul><p>${link(hubPath(product),'See all features')}</p></section>`;
 if(!template.includes(`id="omevision-feature-directory-${product.id}"`))await writeFile(join(dist,homeFile),template.replace(/<\/body>/i,nav+'</body>'));
 return entries;
}
