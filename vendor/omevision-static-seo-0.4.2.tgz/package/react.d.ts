import type {ReactElement} from 'react';
export interface GuideVideo {title:string;url:string;poster:string;duration:number;width:number;height:number;transcript:string;captions:string;startAt?:number;endAt?:number;captionsDefault?:boolean;}
export declare function InstructionalVideo(props:{video:GuideVideo;id?:string;heading?:string;className?:string}):ReactElement;
