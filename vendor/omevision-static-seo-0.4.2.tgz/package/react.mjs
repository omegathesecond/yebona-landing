import {createElement as h,useEffect,useRef} from 'react';
import {renderVideo,mediaCss,enhanceMedia} from './media.mjs';
export function InstructionalVideo({video,id='watch',heading='See how it works',className=''}){const root=useRef(null);useEffect(()=>{if(root.current)return enhanceMedia(root.current,root.current.closest('main')||root.current);},[video.url,id]);return h('div',{className,ref:root},h('style',{dangerouslySetInnerHTML:{__html:mediaCss}}),h('div',{dangerouslySetInnerHTML:{__html:renderVideo(video,{id,heading})}}));}
