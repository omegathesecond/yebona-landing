import {escapeHtml as e} from './edge.mjs';
export function validateVideo(video){
 if(!video||!video.title||!video.url||!video.poster||!Number.isFinite(video.duration)||video.duration<=0)throw new Error('A published instructional video is required');
 for(const value of [video.url,video.poster,video.captions].filter(Boolean)){const url=new URL(value,'https://example.invalid');if(url.protocol!=='https:'||url.username||url.password)throw new Error('Unsafe video asset');}
 if(!Number.isFinite(video.width)||!Number.isFinite(video.height)||video.width<1||video.height<1)throw new Error('Missing video dimensions');
 if(!video.transcript?.trim())throw new Error('An instructional video needs its transcript');
 for(const field of ['startAt','endAt'])if(video[field]!==undefined&&(!Number.isFinite(video[field])||video[field]<0||video[field]>video.duration+0.001))throw new Error('Invalid instructional video chapter');
 if(video.endAt!==undefined&&video.endAt<=(video.startAt||0))throw new Error('Invalid instructional video chapter range');
}
export function renderVideo(video,{id='watch',heading='See how it works'}={}){
 validateVideo(video);
 const portrait=video.height>video.width;
 const source=video.url+(video.startAt!==undefined||video.endAt!==undefined?'#t='+Number(video.startAt||0)+(video.endAt!==undefined?','+video.endAt:''):'');
 const shownDuration=(video.endAt??video.duration)-(video.startAt||0);
 return `<section id="${e(id)}" class="guide-video" aria-label="${e(heading||video.title)}">${heading?`<h2>${e(heading)}</h2>`:''}<figure data-guide-player><div class="guide-video-frame${portrait?' guide-video-portrait':''}" style="--video-ratio:${video.width}/${video.height}"><video controls playsinline preload="none" crossorigin="anonymous" poster="${e(video.poster)}" aria-label="${e(video.title)}"><source src="${e(source)}" type="video/mp4">${video.captions?`<track${video.captionsDefault?' default':''} kind="captions" src="${e(video.captions)}" srclang="en" label="English">`:''}<p><a href="${e(video.url)}">Open the video</a> or read the steps below.</p></video></div><p data-video-error role="alert" hidden>The video could not load. <button type="button" data-video-retry>Try again</button> or <a href="${e(video.url)}">open the video</a>.</p><p data-caption-error role="alert" hidden>Captions could not load. You can read the transcript below.</p><figcaption><span>${e(video.title)}</span><span>${Math.round(shownDuration)} sec${video.captions?' · English captions':''}</span></figcaption><details><summary>Read the video transcript</summary><div>${video.transcript.split(/\n\n+/).map(p=>`<p>${e(p)}</p>`).join('')}</div></details></figure></section>`;
}
export const mediaCss=`.guide-video{min-width:0;scroll-margin-top:24px}.guide-video h2{font-size:1.15rem;margin:0 0 14px}.guide-video figure{margin:0}.guide-video-frame{overflow:hidden;border:1px solid var(--line,#dce3dd);border-radius:16px;background:#101713;aspect-ratio:var(--video-ratio,16/9)}.guide-video-frame video{display:block;width:100%;height:100%;object-fit:contain}.guide-video-portrait{max-width:390px;max-height:580px;margin:auto}.guide-video figcaption{display:flex;flex-wrap:wrap;justify-content:space-between;gap:8px;margin-top:12px;font-size:.8rem;color:var(--muted,#52625c)}.guide-video details{margin-top:14px;font-size:.9rem}.guide-video summary{cursor:pointer;font-weight:600}.guide-video [role=alert]{padding:14px;background:#fff4ef;color:#832f16;border-radius:10px;font-size:.9rem}.guide-video button{border:0;background:none;color:inherit;text-decoration:underline;cursor:pointer;font:inherit;padding:0}.guide-video video::cue{font-size:17px}.dark .guide-video{--muted:#cbd5e1;--line:#334155}.guide-video [hidden]{display:none!important}`;
export function enhanceMedia(root,watchRoot=root){
 const cleanups=[];
 const bind=(element,event,handler)=>{element?.addEventListener(event,handler);if(element)cleanups.push(()=>element.removeEventListener(event,handler));};
 for(const player of root.querySelectorAll('[data-guide-player]')){
  if(player.dataset.guideReady==='1')continue;player.dataset.guideReady='1';cleanups.push(()=>delete player.dataset.guideReady);
  const video=player.querySelector('video'),error=player.querySelector('[data-video-error]'),caption=player.querySelector('[data-caption-error]');
  const fail=()=>{error.hidden=false;};bind(video,'error',fail);bind(video.querySelector('source'),'error',fail);bind(video.querySelector('track'),'error',()=>{caption.hidden=false;});
  bind(player.querySelector('[data-video-retry]'),'click',()=>{error.hidden=true;video.load();video.play().catch(fail);});
 }
 for(const link of watchRoot.querySelectorAll('[data-watch-video]'))bind(link,'click',event=>{const target=link.ownerDocument.querySelector(link.getAttribute('href'));const video=target?.querySelector('video');if(video){event.preventDefault();target.scrollIntoView({behavior:'smooth',block:'center'});video.play().catch(()=>{const error=target.querySelector('[data-video-error]');if(error)error.hidden=false;});}});
 return ()=>cleanups.reverse().forEach(cleanup=>cleanup());
}
export const mediaRuntime=`(${enhanceMedia.toString()})(document);`;
