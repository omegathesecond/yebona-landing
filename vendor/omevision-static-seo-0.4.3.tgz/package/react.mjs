import {createElement as h,useEffect,useRef} from 'react';
import {renderVideo,mediaCss,enhanceMedia} from './media.mjs';
export function InstructionalVideo({video,id='watch',heading='See how it works',className=''}){const root=useRef(null),markup=renderVideo(video,{id,heading});useEffect(()=>{if(root.current)return enhanceMedia(root.current,root.current.closest('main')||root.current);},[markup]);return h('div',{className,ref:root},h('style',{dangerouslySetInnerHTML:{__html:mediaCss}}),h('div',{dangerouslySetInnerHTML:{__html:markup}}));}
