export interface ClientPageConfig {clientPaths:string[];privatePaths:string[];}
export function clientPage(request:Request,assets:{fetch(request:Request):Promise<Response>},config:ClientPageConfig):Promise<Response|null>;
export function clientPageMiddleware(config:ClientPageConfig):(context:{request:Request;env:{ASSETS:{fetch(request:Request):Promise<Response>}};next:()=>Promise<Response>})=>Promise<Response>;
