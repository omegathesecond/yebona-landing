import { tagsFor } from './browser.mjs';

const escape = (value) => String(value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

export function rewriteHead(html, meta) {
  const tags = tagsFor(meta);
  if ((html.match(/<head(?:\s[^>]*)?>/gi) ?? []).length !== 1 || !/<\/head>/i.test(html)) throw new Error('Expected one document head');
  return html.replace(/(<head(?:\s[^>]*)?>)([\s\S]*?)(<\/head>)/i, (_, open, head, close) => {
    head = head.replace(/<title\b[^>]*>[\s\S]*?<\/title>/gi, '');
    head = head.replace(/<(meta|link)\b[^>]*>/gi, (tag, kind) => {
      const attrs = Object.fromEntries([...tag.matchAll(/([\w:-]+)\s*=\s*["']([^"']*)["']/g)].map(([, key, value]) => [key.toLowerCase(), value]));
      if (kind.toLowerCase() === 'link' && attrs.rel === 'canonical') return '';
      return tags.some(([attr, key]) => attrs[attr] === key) ? '' : tag;
    });
    // Product-specific application data belongs on the product page, not legal/404 pages.
    head = head.replace(/<script\b[^>]*type=["']application\/ld\+json["'][^>]*>[\s\S]*?<\/script>/gi, '');
    const generated = [`<title>${escape(meta.title)}</title>`, `<link rel="canonical" href="${escape(meta.canonical)}" />`, ...tags.map(([attr, key, value]) => `<meta ${attr}="${key}" content="${escape(value)}" />`)];
    if (meta.structuredData) generated.push(`<script type="application/ld+json">${JSON.stringify(meta.structuredData).replace(/</g, '\\u003c')}</script>`);
    return `${open}${head}\n${generated.join('\n')}\n${close}`;
  });
}

