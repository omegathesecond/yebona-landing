/** Route known client application URLs explicitly; unknown URLs must remain real 404s. */
import {markNoindex} from './edge.mjs';
export function matchClientPath(path,patterns){return patterns.some(pattern=>new RegExp('^'+pattern.split('/').map(part=>part==='*'?'.*':part.startsWith(':')?'[^/]+':part.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('/')+'/?$').test(path));}
export async function serveAppAssets(request,assets,{clientPaths,publicPaths}){
 if(!['GET','HEAD'].includes(request.method))return assets.fetch(request);
 const url=new URL(request.url),path=url.pathname.replace(/\/+$/,'')||'/';
 if(publicPaths.includes(path))return assets.fetch(new Request(new URL(path==='/'?'/index.html':path+'.html',url),{method:request.method}));
 if(matchClientPath(path,clientPaths)){
  const shell=await assets.fetch(new Request(new URL('/index.html',url),{method:'GET'}));
  return markNoindex(shell);
 }
 const response=await assets.fetch(request);
 if(response.status===404||!response.headers.get('content-type')?.includes('text/html'))return response;
 // File-based public HTML is allowed only through the explicit public route list.
 const missing=await assets.fetch(new Request(new URL('/404.html',url),{method:'GET'}));
 const headers=new Headers(missing.headers);headers.set('x-robots-tag','noindex, follow');headers.set('cache-control','no-store');
 return new Response(missing.body,{status:404,headers});
}
