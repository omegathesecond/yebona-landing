export function matchClientPath(path:string,patterns:string[]):boolean;
export function serveAppAssets(request:Request,assets:{fetch(request:Request):Promise<Response>},config:{clientPaths:string[];publicPaths:string[]}):Promise<Response>;
