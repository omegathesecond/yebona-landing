import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {join,dirname} from 'node:path';
import {buildFeatures,featureMetadata} from '@omevision/static-seo/features';
import {rewriteHead} from '@omevision/static-seo';
import {clientPathsFromSources} from './routes.mjs';
import {escapeHtml} from '@omevision/static-seo/edge';
const root=process.cwd(),dist=join(root,'dist');
const config=JSON.parse(await readFile(join(root,'seo/site.json'),'utf8'));
const product=JSON.parse(await readFile(join(root,'seo/product.json'),'utf8'));
const origin='https://'+config.host;
if(config.clientRouteSources){
 const derived=await clientPathsFromSources(root,config.clientRouteSources);
 config.client=derived.filter(path=>path!=='/'&&!config.public.includes(path)&&!config.discoveryPaths?.includes(path)&&!path.startsWith('/dev/'));
}

const privatePaths=config.private||config.client.filter(p=>/^\/(auth|oauth|login|onboarding|my|my-trips|my-listings|account|profile|post|drafts|messages|settings|checkout|invoice|pop|bookings|notifications|route-alerts|admin|dealer|engagements|appointments|worker|credits|survey|applications|sell|recovery)(\/|$)/.test(p));
await writeFile(join(root,'seo/client-routes.json'),JSON.stringify({clientPaths:config.client,privatePaths},null,2));
if(process.argv.includes('--prepare')){
 const publicProduct={name:product.name,features:product.features.map(({sources,availability,word_count,...feature})=>feature)};
 await writeFile(join(root,'seo/public-product.json'),JSON.stringify(publicProduct,null,2));
 process.exit(0);
}

const template=await readFile(join(dist,config.homeFile||'index.html'),'utf8');
const oldTitle=template.match(/<title\b[^>]*>([\s\S]*?)<\/title>/i)?.[1];
const oldDescription=template.match(/<meta\b(?=[^>]*name=["']description["'])(?=[^>]*content=["']([^"']*)["'])[^>]*>/i)?.[1];
let urls=[];
try{const xml=await readFile(join(dist,'sitemap.xml'),'utf8');if(xml.includes('<urlset'))urls=[...xml.matchAll(/<loc>([^<]+)<\/loc>/g)].map(x=>x[1]);}catch(error){if(error.code!=='ENOENT')throw error;}
if(config.render){
 const {render,prepare}=await import(join(root,'dist-seo/entry.js'));
 const context=prepare?await prepare():undefined;
 for(const path of config.public){
  // Authored buildless pages do not need replacement by a JavaScript renderer.
  if(config.staticPublic?.includes(path)){urls.push(origin+path);continue;}
  let markup=render(path,context);
  if(typeof markup!=='string'||!/<h1[\s>]/i.test(markup))throw new Error(`Missing readable public page ${path}`);
  const known=product.features.find(f=>(f.existing_path||f.path)===path);
  const label=path.split('/').filter(Boolean).map(s=>s.replaceAll('-',' ')).join(' — ');
  const meta=known?featureMetadata(product,known):{path,title:path==='/'?(config.title||oldTitle):`${label.replace(/^./,c=>c.toUpperCase())} | ${product.name}`,description:path==='/'?(config.description||oldDescription):`${label.replace(/^./,c=>c.toUpperCase())} information from ${product.name}.`,canonical:origin+(path==='/'?'/':path)};
  const html=rewriteHead(template,meta).replace('<div id="root"></div>',()=>`<div id="root">${markup}</div>`);
  const file=join(dist,path==='/'?(config.homeFile||'index.html'):path.slice(1)+'.html');await mkdir(dirname(file),{recursive:true});await writeFile(file,html);
  if(!urls.includes(meta.canonical))urls.push(meta.canonical);
 }
}
const preserveExisting=product.features.filter(f=>f.existing_path&&config.public.includes(f.existing_path)).map(f=>f.existing_path);
const entries=await buildFeatures({dist,product,preserveExisting,homeFile:config.homeFile||'index.html',preserveHub:Boolean(config.preserveHub)});
urls.push(...entries.filter(p=>!p.noindex).map(p=>origin+p.path));
// Readable initial content stays visible with scripting disabled, including entrance animations.
const visibility='<noscript><style>#root [style*="opacity:0"],#root [style*="opacity: 0"],#root .opacity-0,#root .reveal{opacity:1!important;transform:none!important;visibility:visible!important}</style></noscript>';
for(const path of ['/',...config.public].filter((x,i,a)=>a.indexOf(x)===i)){
 const file=join(dist,path==='/'?(config.homeFile||'index.html'):path.slice(1)+'.html');
 try{let html=await readFile(file,'utf8');if(!html.includes(visibility))await writeFile(file,html.replace('</head>',visibility+'</head>'));}catch(error){if(error.code!=='ENOENT')throw error;}
}
// A real missing-page document disables the platform's implicit SPA fallback.
const missing=rewriteHead(`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head><body><main style="max-width:48rem;margin:4rem auto;padding:24px;font:18px/1.7 system-ui"><h1>Page not found</h1><p>This ${escapeHtml(product.name)} page could not be found.</p><a href="/">Return to ${escapeHtml(product.name)}</a><p><a href="/features">Explore features</a></p></main></body></html>`,{title:`Page not found | ${product.name}`,description:`This ${product.name} page could not be found.`,canonical:origin+'/404',noindex:true});
await writeFile(join(dist,'404.html'),missing);
urls.push(...config.public.map(path=>origin+path));
if(!urls.some(url=>new URL(url).pathname==='/'))urls.push(origin+'/');
const unique=[...new Set(urls)].filter(u=>new URL(u).origin===origin&&!new URL(u).search&&!new URL(u).hash&&!new URL(u).pathname.match(/^\/(404|post|auth|login|signup|recover-api-key|reset-api-key)(\/|$)/));
if(!['yeboshops','yebojobs','yeboid'].includes(product.id))await writeFile(join(dist,'sitemap.xml'),`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${unique.map(url=>`<url><loc>${escapeHtml(url)}</loc></url>`).join('')}</urlset>`);
await writeFile(join(dist,'seo-public-paths.json'),JSON.stringify(unique.map(u=>new URL(u).pathname)));
let robots=`User-agent: *\nAllow: /\nSitemap: ${origin}/sitemap.xml\n`;
await writeFile(join(dist,'robots.txt'),robots);
// Keep existing explicit aliases/CMS paths, and replace only the blanket SPA rewrite.
let redirects='';try{redirects=await readFile(join(dist,'_redirects'),'utf8');}catch(error){if(error.code!=='ENOENT')throw error;}
redirects=redirects.split('\n').filter(l=>!/^\/\*\s+\/(?:index\.html|index)\s+200\s*$/.test(l.trim())).join('\n').trim();
for(const pattern of (config.clientMiddleware?[]:config.client)){const rule=`${pattern} /index.html 200`;if(!redirects.includes(rule))redirects+='\n'+rule;}
await writeFile(join(dist,'_redirects'),redirects.trim()+'\n');
// Preserve current security headers and add exclusion headers only for private/transactional client routes.
let headers='';try{headers=await readFile(join(dist,'_headers'),'utf8');}catch(error){if(error.code!=='ENOENT')throw error;}
for(const pattern of privatePaths){headers+=`\n${pattern}\n  X-Robots-Tag: noindex, follow\n  Cache-Control: no-store\n`;}
await writeFile(join(dist,'_headers'),headers);
console.log(`${product.name}: ${entries.length} feature URLs; ${unique.length} static public sitemap URLs`);
