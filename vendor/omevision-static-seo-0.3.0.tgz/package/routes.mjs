import {readFile} from 'node:fs/promises';
import {join} from 'node:path';
/** Derive the deployed client URL list from the router source, including nested routes. */
export async function clientPathsFromSources(root,files){
 const ts=await import('typescript');const result=new Set();
 const attrPath=element=>{const attr=element.attributes.properties.find(p=>ts.isJsxAttribute(p)&&p.name.text==='path');return attr?.initializer&&ts.isStringLiteral(attr.initializer)?attr.initializer.text:null;};
 const visit=(node,prefix='')=>{
  if(ts.isJsxElement(node)||ts.isJsxSelfClosingElement(node)){
   const element=ts.isJsxElement(node)?node.openingElement:node;
   if(element.tagName.getText()==='Route'){
    const path=attrPath(element);let next=prefix;
    if(path!==null&&path!=='*'&&path!=='/*'){
     next=path.startsWith('/')?path:`${prefix.replace(/\/$/,'')}/${path}`;
     result.add(next||'/');
    }
    if(ts.isJsxElement(node))for(const child of node.children)visit(child,next);
    return;
   }
  }
  ts.forEachChild(node,child=>visit(child,prefix));
 };
 for(const file of files){const source=await readFile(join(root,file),'utf8');visit(ts.createSourceFile(file,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX));}
 return [...result];
}
