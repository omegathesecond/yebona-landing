/** Metadata shared by the static build and client navigation. */
export function tagsFor(meta) {
  if (!meta.title || !meta.description || !meta.canonical) throw new Error('Incomplete page metadata');
  const url = new URL(meta.canonical);
  if (url.protocol !== 'https:' || url.search || url.hash) throw new Error('Canonical must be a public HTTPS URL without query or fragment');
  return [
    ['name', 'title', meta.title],
    ['name', 'description', meta.description],
    ['name', 'robots', meta.noindex ? 'noindex, follow' : 'index, follow'],
    ['property', 'og:title', meta.title],
    ['property', 'og:description', meta.description],
    ['property', 'og:url', meta.canonical],
    ['name', 'twitter:title', meta.title],
    ['name', 'twitter:description', meta.description],
    ['name', 'twitter:url', meta.canonical],
  ];
}

export function applyPageMeta(document, meta) {
  const tags = tagsFor(meta);
  document.title = meta.title;
  for (const [attr, key, value] of tags) {
    const matches = [...document.head.querySelectorAll(`meta[${attr}="${key}"]`)];
    const tag = matches.shift() ?? document.createElement('meta');
    matches.forEach((duplicate) => duplicate.remove());
    tag.setAttribute(attr, key);
    tag.setAttribute('content', value);
    document.head.appendChild(tag);
  }
  const links = [...document.head.querySelectorAll('link[rel="canonical"]')];
  const canonical = links.shift() ?? document.createElement('link');
  links.forEach((duplicate) => duplicate.remove());
  canonical.setAttribute('rel', 'canonical');
  canonical.setAttribute('href', meta.canonical);
  document.head.appendChild(canonical);
  document.head.querySelectorAll('script[type="application/ld+json"]').forEach((tag) => tag.remove());
  if (meta.structuredData) {
    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.textContent = JSON.stringify(meta.structuredData).replace(/</g, '\\u003c');
    document.head.appendChild(script);
  }
}
