import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { join, dirname } from 'node:path';

export { rewriteHead } from './head.mjs';
import { rewriteHead } from './head.mjs';
const escape = (value) => String(value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

export async function renderSite({ dist, origin, pages, render }) {
  if (new URL(origin).origin !== origin || !origin.startsWith('https://')) throw new Error('Invalid production origin');
  if (!pages.length || !pages.some((page) => page.path === '/')) throw new Error('Missing homepage');
  const paths = pages.map(({ path }) => path);
  if (new Set(paths).size !== paths.length) throw new Error('Duplicate page path');
  const template = await readFile(join(dist, 'index.html'), 'utf8');
  const root = '<div id="root"></div>';
  if (template.split(root).length !== 2) throw new Error('Expected exactly one empty application root');
  const robots = await readFile(join(dist, 'robots.txt'), 'utf8');
  if (!robots.includes(`Sitemap: ${origin}/sitemap.xml`)) throw new Error('Missing canonical sitemap in robots.txt');
  const outputs = [];
  // Render and validate every page before writing any output. Render errors fail the build.
  for (const page of pages) {
    if (!/^\/(?:[a-z0-9-]+(?:\/[a-z0-9-]+)*)?$/.test(page.path)) throw new Error(`Unsafe page path: ${page.path}`);
    const canonical = origin + (page.path === '/' ? '/' : page.path);
    if (page.canonical !== canonical && !(page.path === '/' && page.canonical === origin)) throw new Error(`Canonical mismatch: ${page.path}`);
    const markup = await render(page.path);
    if (!markup || !/<h1[\s>]/i.test(markup)) throw new Error(`Missing rendered h1: ${page.path}`);
    const html = rewriteHead(template, page).replace(root, () => `<div id="root">${markup}</div>`);
    const file = page.path === '/' ? 'index.html' : `${page.path.slice(1)}.html`;
    outputs.push({ file, html });
  }
  for (const { file, html } of outputs) {
    await mkdir(dirname(join(dist, file)), { recursive: true });
    await writeFile(join(dist, file), html);
  }
  const urls = pages.filter((p) => !p.noindex).map((p) => `  <url><loc>${escape(p.canonical)}</loc></url>`);
  await writeFile(join(dist, 'sitemap.xml'), `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.join('\n')}\n</urlset>\n`);
  console.log(`Prerendered ${outputs.length} pages; ${urls.length} indexable URLs for ${origin}`);
}

/** Checks deployed-build files without executing client JavaScript. */
export async function checkSite(dist) {
  const map = await readFile(join(dist, 'sitemap.xml'), 'utf8');
  if (!map.includes('<urlset') || map.includes('<html')) throw new Error('Sitemap is not XML');
  const urls = [...map.matchAll(/<loc>([^<]+)<\/loc>/g)].map(([, url]) => url);
  if (!urls.length || new Set(urls).size !== urls.length) throw new Error('Empty or duplicate sitemap');
  for (const url of urls) {
    const path = new URL(url).pathname;
    const file = path === '/' ? 'index.html' : `${path.slice(1)}.html`;
    const html = await readFile(join(dist, file), 'utf8');
    const head = html.match(/<head\b[^>]*>([\s\S]*?)<\/head>/i)?.[1] ?? '';
    for (const [label, regex] of [['title', /<title\b/g], ['description', /<meta\s+name="description"/g], ['canonical', /<link\s+rel="canonical"/g], ['robots', /<meta\s+name="robots"/g]]) {
      if ((head.match(regex) ?? []).length !== 1) throw new Error(`${url}: expected one ${label}`);
    }
    if (!/<h1\b[^>]*>[\s\S]*?\w[\s\S]*?<\/h1>/i.test(html)) throw new Error(`${url}: missing h1 text`);
    if (/<div id="root"><\/div>/.test(html)) throw new Error(`${url}: empty application root`);
    if (!head.includes(`href="${url}"`)) throw new Error(`${url}: incorrect canonical`);
    if (/name="robots"\s+content="[^"]*noindex/.test(head)) throw new Error(`${url}: noindex page in sitemap`);
    for (const [, data] of head.matchAll(/<script\b[^>]*type="application\/ld\+json"[^>]*>([\s\S]*?)<\/script>/g)) JSON.parse(data);
  }
  const missing = await readFile(join(dist, '404.html'), 'utf8');
  if (!/name="robots" content="noindex, follow"/.test(missing)) throw new Error('404 page must be noindex');
  console.log(`SEO checks passed: ${urls.length} indexable pages and a noindex 404`);
  return urls.length;
}
