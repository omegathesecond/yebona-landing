import { rewriteHead } from './head.mjs';
export const escapeHtml = (value) => String(value).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
export class DiscoveryError extends Error {
  constructor(message, status = 502) { super(message); this.status = status; }
}
export async function publicJson(url, { missing = false, fetcher = fetch } = {}) {
  let response;
  try { response = await fetcher(url, { headers:{ accept:'application/json' }, redirect:'manual', signal:AbortSignal.timeout(10000) }); }
  catch (error) {
    console.error('Public listing request failed', { host:new URL(url).hostname, reason:error instanceof Error?error.message:'Transport failure' });
    throw new DiscoveryError('Public listing service is unavailable', 503);
  }
  if (response.status === 404 && missing) return null;
  if (!response.ok) throw new DiscoveryError('Public listing service returned an error');
  let json;
  try { json = await response.json(); } catch { throw new DiscoveryError('Public listing service returned invalid JSON'); }
  if (json?.success !== true) throw new DiscoveryError('Public listing service rejected the request');
  return json;
}
export function markNoindex(response) {
  const headers = new Headers(response.headers);headers.set('x-robots-tag','noindex, follow');headers.set('cache-control','no-store');
  return new Response(response.body, { status:response.status, headers });
}
function htmlResponse(html, status=200, indexable=true) {
  return new Response(html, {status,headers:{'content-type':'text/html; charset=utf-8','cache-control':status===200&&indexable?'public, max-age=60, s-maxage=60':'no-store',...(indexable?{}:{'x-robots-tag':'noindex, follow'})}});
}
export function discoveryErrorResponse(error, name) {
  const status=error instanceof DiscoveryError?error.status:502;
  const heading=status===404?'Listing not found':status===410?'Listing no longer available':'Unable to load listings';
  return htmlResponse(`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex, follow"><title>${heading} | ${escapeHtml(name)}</title></head><body><main><h1>${heading}</h1><p>${status>=500?'The listing service could not be reached. Please try again.':'Browse the current public listings for available items.'}</p>${status>=500?'<button onclick="location.reload()">Try again</button>':''}<p><a href="/">Browse ${escapeHtml(name)}</a></p></main></body></html>`,status,false);
}
const validDate = (value) => typeof value==='string' && !Number.isNaN(Date.parse(value));
export function sitemapResponse(entries) {
  if (entries.length>50000) throw new DiscoveryError('Sitemap exceeds protocol size limit');
  const seen=new Set();
  const xml=entries.map(({url,lastmod})=>{
    const parsed=new URL(url);if(parsed.protocol!=='https:'||parsed.search||parsed.hash||seen.has(url))throw new DiscoveryError('Invalid or duplicate sitemap URL');seen.add(url);
    if(lastmod!==undefined&&!validDate(lastmod))throw new DiscoveryError('Invalid sitemap date');
    return `<url><loc>${escapeHtml(url)}</loc>${lastmod?`<lastmod>${new Date(lastmod).toISOString()}</lastmod>`:''}</url>`;
  }).join('\n');
  return new Response(`<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${xml}\n</urlset>\n`,{headers:{'content-type':'application/xml; charset=utf-8','cache-control':'public, max-age=300, s-maxage=300'}});
}
export async function handleDiscovery(request, loadShell, config) {
  const url=new URL(request.url);const path=url.pathname.replace(/\/+$/,'')||'/';
  if(!['GET','HEAD'].includes(request.method))return null;
  const trackingOnly=[...url.searchParams.keys()].every((key)=>/^(utm_.+|gclid|fbclid|ref)$/.test(key));
  const match=path.match(config.detailPattern);const isCollection=config.collectionPaths.includes(path);
  const isMap=config.sitemapPaths.includes(path);
  if(!match&&!isCollection&&!isMap&&path!=='/robots.txt')return null;
  try {
    if(path==='/robots.txt')return new Response(`User-agent: *\nAllow: /\n\nSitemap: ${config.origin}/sitemap.xml\n`,{headers:{'content-type':'text/plain; charset=utf-8','cache-control':'public, max-age=300'}});
    const json=(target,options)=>publicJson(target,{...options,fetcher:config.fetcher??fetch});
    const readPage=async(page)=>{
      const result=await config.listPage(page,json);
      if(!result||!Array.isArray(result.items)||typeof result.hasNext!=='boolean')throw new DiscoveryError('Invalid listing pagination');
      return {items:result.items.map(config.decode),hasNext:result.hasNext};
    };
    if(isMap){
      const entries=[...new Set([...config.collectionPaths,...(config.staticPaths??[])])].map((p)=>({url:config.origin+(p==='/'?'/':p)}));
      for(let page=1;page<=500;page++){
        const {items,hasNext}=await readPage(page);
        for(const item of items)if(config.visibility(item)==='public'){
          const data=config.describe(item);entries.push({url:config.origin+data.path,...(data.lastmod?{lastmod:data.lastmod}:{})});
        }
        if(!hasNext)return sitemapResponse(entries);
      }
      throw new DiscoveryError('Listing pagination exceeded sitemap safety limit');
    }
    if(!trackingOnly)return markNoindex(await loadShell());
    let meta;let body;
    if(match){
      let key;
      try{key=decodeURIComponent(match[1]);}catch{throw new DiscoveryError('Invalid listing URL',404);}
      if(!key||key.includes('/')||key.length>300)throw new DiscoveryError('Invalid listing URL',404);
      const raw=await config.getItem(key,json);if(raw===null)throw new DiscoveryError('Listing not found',404);
      const item=config.decode(raw);const state=config.visibility(item);
      if(state!=='public')throw new DiscoveryError('Listing unavailable',state==='gone'?410:404);
      const data=config.describe(item);
      meta={path:data.path,title:data.title,description:data.description,canonical:config.origin+data.path,structuredData:data.structuredData};body=data.body;
    }else{
      const {items}=await readPage(1);const visible=items.filter((item)=>config.visibility(item)==='public').slice(0,24);
      const rows=visible.map((item)=>{const data=config.describe(item);return `<li><a href="${escapeHtml(data.path)}">${escapeHtml(data.title)}</a><p>${escapeHtml(data.description)}</p></li>`;}).join('');
      body=`<h1>${escapeHtml(config.heading)}</h1><p>${escapeHtml(config.description)}</p>${visible.length?`<ul>${rows}</ul>`:'<p>No public listings are available right now.</p>'}`;
      meta={path,title:config.heading,description:config.description,canonical:config.origin+(path==='/'?'/':path),structuredData:{'@context':'https://schema.org','@type':'WebSite',name:config.name,url:config.origin,publisher:{'@type':'Organization',name:config.name,parentOrganization:{'@type':'Organization','@id':'https://omevision.com/#organization',name:'Omevision',url:'https://omevision.com/'}}}};
    }
    const shell=await loadShell();if(!shell.ok)throw new DiscoveryError('Site shell is unavailable',503);
    const html=await shell.text();if(!html.includes('<div id="root"></div>'))throw new DiscoveryError('Unexpected site shell');
    const content=`<main style="max-width:64rem;margin:2rem auto;padding:1rem;font:1rem/1.6 system-ui"><a href="/">${escapeHtml(config.name)}</a>${body}<p>Part of <a href="https://omevision.com/">Omevision</a>.</p></main>`;
    return htmlResponse(rewriteHead(html,meta).replace('<div id="root"></div>',()=>`<div id="root">${content}</div>`));
  }catch(error){return discoveryErrorResponse(error,config.name);}
}
