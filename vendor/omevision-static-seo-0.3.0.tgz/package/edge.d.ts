export class DiscoveryError extends Error { status:number; constructor(message:string,status?:number); }
export function escapeHtml(value:unknown):string;
export function publicJson(url:string,options?:{missing?:boolean;fetcher?:typeof fetch}):Promise<any>;
export function markNoindex(response:Response):Response;
export function discoveryErrorResponse(error:unknown,name:string):Response;
export function sitemapResponse(entries:{url:string;lastmod?:string}[]):Response;
export interface DiscoveryPage {path:string;title:string;description:string;body:string;structuredData?:unknown;lastmod?:string;}
export interface DiscoveryConfig<T> {
 origin:string;name:string;heading:string;description:string;detailPattern:RegExp;collectionPaths:string[];sitemapPaths:string[];staticPaths?:string[];fetcher?:typeof fetch;
 listPage(page:number,json:typeof publicJson):Promise<{items:unknown[];hasNext:boolean}>;
 getItem(key:string,json:typeof publicJson):Promise<unknown|null>;
 decode(value:unknown):T;
 visibility(item:T):'public'|'gone'|'private';
 describe(item:T):DiscoveryPage;
}
export function handleDiscovery<T>(request:Request,loadShell:()=>Promise<Response>,config:DiscoveryConfig<T>):Promise<Response|null>;
