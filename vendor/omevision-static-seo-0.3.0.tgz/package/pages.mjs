import {matchClientPath} from './assets.mjs';
/** Preserve only declared SPA routes and prevent indexing of account/transaction pages. */
export async function clientPage(request,assets,{clientPaths,privatePaths}){
 const path=new URL(request.url).pathname;
 if(!['GET','HEAD'].includes(request.method)||!matchClientPath(path,clientPaths))return null;
 const shell=await assets.fetch(new Request(new URL('/',request.url),{method:'GET'}));
 const headers=new Headers(shell.headers);headers.set('cache-control','no-store');
 if(matchClientPath(path,privatePaths))headers.set('x-robots-tag','noindex, follow');
 return new Response(request.method==='HEAD'?null:shell.body,{status:shell.status,headers});
}
export function clientPageMiddleware(config){return async context=>(await clientPage(context.request,context.env.ASSETS,config))||context.next();}
