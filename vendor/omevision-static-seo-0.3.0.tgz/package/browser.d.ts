export interface PageMeta { title: string; description: string; canonical: string; noindex?: boolean; structuredData?: unknown; }
export function tagsFor(meta: PageMeta): string[][];
export function applyPageMeta(document: Document, meta: PageMeta): void;
